<?php
$figura=$_POST['figu'];
$resp=$_POST['resp'];
$email=$_POST['email'];

if ((empty($email))||(empty($resp))||(empty($figura))) {
    echo 2;
}
else {
    $rep="<html><body>\n";
	$rep=$rep . "<p>Repuesta del Cálculo Realizado para la figura: <b>$figura</b></p>\n";
	$rep=$rep . "<p>Área:<b>$resp</b></p>\n";
	$rep=$rep . "</body></html>\n";
	$to = $email;
	$subject = "Repuesta del Cálculo";
	$headers = "From: dannetavila@gmail.com\r\n".
		   "X-Mailer: envio.php\r\n" .
		   "Content-Type: text/html; charset=\"iso-8859-1\"";

	if (!mail($to, $subject, $rep, $headers)) {
	   echo("3");
	}
  else {
      echo 1;
  }
}
?>
