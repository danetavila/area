$(document).ready(function(){
    $("#figuras").change(function(e) {
            var fselect=$("#figuras option:selected").val();
            if (fselect!='') {
                $(".botton").removeClass("hidden");
		$(".cargando").removeClass("hidden");
                switch (fselect) {
                    case 'cuadrado':
                        $("#par1").removeClass("hidden");
                        $("#par2").addClass("hidden");
                        $("#par3").addClass("hidden");
                        $("#label1").empty().html("Lado");
			$("#para1").val('');
			$("#para2").val('');	
			$("#para3").val('');		
			$("#forme").addClass("hidden");
		        $("#result").empty().html("");			
                        break;
                    case 'rectangulo':
                        $("#par1").removeClass("hidden");
                        $("#par2").removeClass("hidden");
                        $("#par3").addClass("hidden");
                        $("#label1").empty().html("Base");
                        $("#label2").empty().html("Altura");
			$("#para1").val('');
			$("#para2").val('');	
			$("#para3").val('');		
			$("#forme").addClass("hidden");
		        $("#result").empty().html("");			
                        break;
                    case 'triangulo':
                        $("#par1").removeClass("hidden");
                        $("#par2").removeClass("hidden");
                        $("#par3").addClass("hidden");
                        $("#label1").empty().html("Base");
                        $("#label2").empty().html("Altura");
			$("#para1").val('');
			$("#para2").val('');	
			$("#para3").val('');		
			$("#forme").addClass("hidden");
		        $("#result").empty().html("");
                        break;
                    case 'paralelogramo':
                        $("#par1").removeClass("hidden");
                        $("#par2").removeClass("hidden");
                        $("#par3").addClass("hidden");
                        $("#label1").empty().html("Base");
                        $("#label2").empty().html("Altura");
			$("#para1").val('');
			$("#para2").val('');	
			$("#para3").val('');		
			$("#forme").addClass("hidden");
		        $("#result").empty().html("");
                        break;
                    case 'trapecio':
                        $("#par1").removeClass("hidden");
                        $("#par2").removeClass("hidden");
                        $("#par3").removeClass("hidden");
                        $("#label1").empty().html("Base Mayor");
                        $("#label2").empty().html("Base Menor");
                        $("#label3").empty().html("Altura");
			$("#para1").val('');
			$("#para2").val('');	
			$("#para3").val('');		
			$("#forme").addClass("hidden");
		        $("#result").empty().html("");
                    break;
                    case 'circulo':
                        $("#par1").removeClass("hidden");
                        $("#par2").addClass("hidden");
                        $("#par3").addClass("hidden");
                        $("#label1").empty().html("Radio");
			$("#para1").val('');
			$("#para2").val('');	
			$("#para3").val('');		
			$("#forme").addClass("hidden");
		        $("#result").empty().html("");
                        break;
                }
                $("#imagen").attr('src','images/'+fselect+'.jpg');
		$(".cargando").addClass("hidden");
            }
            else {

                $("#forme").addClass("hidden");
                $("#par1").addClass("hidden");
                $("#par2").addClass("hidden");
                $("#par3").addClass("hidden");
                $(".botton").addClass("hidden");
                $('#reset').click();
                $("#imagen").attr('src','images/todos.jpg');
		$(".cargando").addClass("hidden");
            }
    });

    $("#calcular").click(function(e) {
        e.preventDefault();	
        var fselect=$("#figuras option:selected").val();	
        if (fselect!='') {
            $(".botton").removeClass("hidden");
	    $(".cargando").removeClass("hidden");
            switch (fselect) {
                case 'cuadrado':
                    l1=$("#para1").val();
                    if(l1!=''){
                        var calc=(l1*l1);
                        $('#result').empty().append('<h3>'+calc+'</h3>');
                        $('#resp').val(calc);
			$('#figu').val(fselect);
                        $('#forme').removeClass("hidden");
			$(".cargando").addClass("hidden");	
                    }
                    else {
                        alert('ingrese un valor');
                    }
                    break;
                case 'rectangulo':
                    base=$("#para1").val();
                    altura=$("#para2").val();
                    if((altura!='')&&(base!='')){
                        var calc=(base*altura);
                        $('#result').empty().append('<h3>'+calc+'</h3>');
                        $('#resp').val(calc);
			$('#figu').val(fselect);
                        $('#forme').removeClass("hidden");
			$(".cargando").addClass("hidden");
                    }
                    else {
                        alert('ingrese los valores');
                    }
                    break;
                case 'triangulo':
                    base=$("#para1").val();
                    altura=$("#para2").val();
                    if((base!='')&&(altura!='')){
                        var calc=((base*altura)/2);
                        $('#result').empty().append('<h3>'+calc+'</h3>');
                        $('#resp').val(calc);
			$('#figu').val(fselect);
                        $('#forme').removeClass("hidden");
			$(".cargando").addClass("hidden");
                    }
                    else {
                        alert('ingrese los valores');
                    }
                    break;
                case 'paralelogramo':
                    base=$("#para1").val();
                    altura=$("#para2").val();
                    if((base!='')&&(altura!='')){
                        var calc=(base*altura);
                        $('#result').empty().append('<h3>'+calc+'</h3>');
                        $('#resp').val(calc);
			$('#figu').val(fselect);
                        $('#forme').removeClass("hidden");
			$(".cargando").addClass("hidden");
                    }
                    else {
                        alert('ingrese los valores');
                    }
                    break;
                case 'trapecio':
                    baseMa=$("#para1").val();
                    baseMe=$("#para2").val();
                    altura=$("#para3").val();
                    if((baseMa!='')&&(baseMe!='')&&(altura!='')){			                      
			var calc=((parseInt(baseMa))+ (parseInt(baseMe)));				
			    calc=((calc/2)*altura);			
                        $('#result').empty().append('<h3>'+calc+'</h3>');
                        $('#resp').val(calc);
			$('#figu').val(fselect);
                        $('#forme').removeClass("hidden");
			$(".cargando").addClass("hidden");
                    }
                    else {
                        alert('ingrese los valores');
                    }
                break;
                case 'circulo':
                    radio=$("#para1").val();
                    if(radio!=''){
                        var calc=(3.14*radio*radio);
                        $('#result').empty().append('<h3>'+calc+'</h3>');
                        $('#resp').val(calc);
			$('#figu').val(fselect);
                        $('#forme').removeClass("hidden");
			$(".cargando").addClass("hidden");
                    }
                    else {
                        alert('ingrese el valor');
                    }
                    break;
            }
        }
    });
	
    $('#bemail').click( function(e) {            
	    e.preventDefault();
            $("#bemail").attr("disabled", true);      
            var datos =$('#forme').serialize();  
	    $(".cargando").removeClass("hidden");
            $.ajax({ 
                url : "envio.php", 
                type: "POST", 
                data : datos, 
                success: function(datos) 
                {                    
                  if(datos=='1'){
			alert("Email enviado con exito");
		  }else
		  {
		       if(datos=='2'){
			  alert("Algunos de los campos están vacíos");
		       }
		       else{
			    if(datos=='3'){
			       alert("Email no puedo ser enviado");
		  	    }
		       }	
		  }	
			$(".botton").addClass("hidden");
			$("#par1").addClass("hidden");
			$("#par2").addClass("hidden");
                        $("#par3").addClass("hidden");
			$('#reset').click();
			$('#breset').click();
			$("#forme").addClass("hidden");
			$("#forme").addClass("hidden");
		        $("#result").empty();
			$(".cargando").addClass("hidden");
		 
                } 
            }); 
        });

});
